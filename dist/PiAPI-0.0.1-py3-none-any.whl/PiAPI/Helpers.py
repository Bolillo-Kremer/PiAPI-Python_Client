class Edge:
    __rising = "rising"
    __falling = "falling"
    __both = "both"

    @classmethod
    def rising(cls):
        return cls.__rising

    @classmethod
    def falling(cls):
        return cls.__falling

    @classmethod
    def both(cls):
        return cls.__both

class Pin:

    __in = "in"
    __out = "out"
    __all = "*"
    __high = 1
    __low = 0
    __toggle = -1

    @classmethod
    def _in(cls):
        return cls.__in

    @classmethod
    def out(cls):
        return cls.__out

    @classmethod
    def high(cls):
        return cls.__high

    @classmethod
    def low(cls):
        return cls.__low

    @classmethod
    def toggle(cls):
        return cls.__toggle

    @classmethod
    def all(cls):
        return cls.__all

class Pull:
    __up = "up"
    __down = "down"

    @classmethod
    def up(cls):
        return cls.__up

    @classmethod
    def down(cls):
        return cls.__down