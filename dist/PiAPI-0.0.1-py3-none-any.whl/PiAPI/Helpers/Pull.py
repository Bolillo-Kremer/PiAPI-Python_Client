class Pull:
    __up = "up"
    __down = "down"

    @classmethod
    def up(cls):
        return cls.__up

    @classmethod
    def down(cls):
        return cls.__down